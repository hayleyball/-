# B00KS0URCE(NSFW)


##### 目前已收录

| 书源 | API | 类型 | 排行榜 | 版本 | 备注 |
| :----: | ------------- | :--: | :----: | :---: | :-----: |
| 疯情书库 | https://m.aaread.club | 网文 | 8 | 1.0.0 |  |
| 94小说 | http://www.94xsw.info | 网文 | 0 | 1.0.0 |  |
| 龙腾小说 | http://www.8qwx.com | 网文 | 20 | 1.0.1 |  |
| 一起色 | http://www.s5217.net | 网文 | 7 | 1.0.0 |  |
| 易读网 | https://www.yidudu1.com | 网文 | 8 | 1.0.1 |  |
| 我的书阁 | http://www.myshuge.org | 网文 | 7 | 1.0.0 |  |
| 大漠阁`beta` | http://www.damoge.cc | 网文 | 7 | 1.0.3 | 正文下一页内容不显示 |
| 海岸线文学 | http://www.haxwx.cc | 网文 | 15 | 1.0.1 |  |
| 瑶池小说 | http://www.yaochixs.com | 网文 | 13 | 1.0.1 |  |
| 牛杂文学 | https://www.nzwxw.com | 网文 | 7 | 1.0.2 | 精确搜索暂不可用 |
---


## Change Log

2019.08.09 新增 牛杂文学


